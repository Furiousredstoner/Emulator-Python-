sudo python3 -m pip install --upgrade pip
sudo pip install pygame